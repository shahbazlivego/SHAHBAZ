export default function Wallet() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Wallet & Payments</h1>
      <p>Link JazzCash, Payoneer, or global wallets. Earnings withdrawal and payment history will appear here.</p>
    </div>
  )
}
export default function Jobs() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Job & Promo Feed</h1>
      <p>Auto-synced job ads and public promotions feed will be fetched and shown here.</p>
    </div>
  )
}
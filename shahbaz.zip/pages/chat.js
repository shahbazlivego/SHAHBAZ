export default function Chat() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Chat Room</h1>
      <p>Real-time chat system placeholder. Peer-to-peer chat + user block/unblock logic to be added with sockets.</p>
    </div>
  )
}
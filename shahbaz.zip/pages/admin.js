export default function Admin() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Admin Panel</h1>
      <p>Admin can block, restrict, remove users, track progress, earnings, and control platform-wide actions.</p>
    </div>
  )
}
export default function VideoCall() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Video Call</h1>
      <p>Secure peer-to-peer video calling coming soon using WebRTC or PeerJS.</p>
    </div>
  )
}
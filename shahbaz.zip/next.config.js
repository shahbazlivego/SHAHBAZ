const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['yourdomain.com'],
  },
}
module.exports = nextConfig;
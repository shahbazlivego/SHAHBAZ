export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white text-sm p-4 text-center">
      © 2025 SHAHBAZ Platform | Powered by ShahbazAngle | All Rights Reserved<br/>
      Designed with ❤️ for universal social growth and earning.
    </footer>
  )
}